"use client"

import { Button } from "@/components/ui/button"
import { Play } from "lucide-react"
import { motion } from "framer-motion"

export default function HeroSection() {
  return (
    <div className="min-h-screen">
      <section className="min-h-screen flex items-start px-6 py-28">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8 z-20 relative">
            <h1 className="font-ranade font-black text-neo-yellow text-5xl md:text-6xl lg:text-7xl leading-tight text-balance uppercase tracking-tight">
              For Students, <span className="text-neo-teal">By Students</span>
            </h1>

            <p className="font-ranade text-muted-foreground text-lg md:text-xl leading-relaxed text-pretty max-w-lg">
              Dive into a world of creativity, innovation, and collaboration.<br />
              Explore past highlights, upcoming events, and showcase the power of student creativity at GSS Clubs.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-neo-teal hover:bg-neo-blue text-white font-ranade font-bold text-lg px-8 py-4 transition-all duration-300 shadow-neo hover:shadow-neo-hover border-2 border-black rounded-none"
              >
                Explore Clubs
              </Button>
              <Button
                size="lg"
                className="bg-neo-blue text-neo-yellow border-2 border-black hover:bg-neo-yellow hover:text-neo-blue font-ranade font-bold text-lg px-8 py-4 transition-all duration-300 shadow-neo hover:shadow-neo-hover rounded-none"
              >
                Events
              </Button>
            </div>
          </div>

          <div className="relative flex items-center justify-center h-[600px] z-10 overflow-visible">
            {/* Tower Building Image - Central */}
            <div className="relative z-10">
              <img
                src="/images/building.png"
                alt="GSS Tower Building"
                className="w-64"
                style={{ width: "auto", height: "auto", maxHeight: 600 }}
              />
            </div>

            {/* Science Club - Top left */}
            <motion.div
              className="absolute top-[-80px] left-[20px] w-56 h-56 z-8"
              animate={{
                x: [0, 5, 0],
              }}
              transition={{
                duration: 6,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut",
              }}
            >
              <img
                src="/placeholder.svg?height=224&width=224"
                alt="Science Club"
                className="w-full h-full object-cover rounded-full shadow-neo border-4 border-black opacity-85"
              />
            </motion.div>

            {/* Robotics Club - Top right */}
            <motion.div
              className="absolute top-[-96px] right-[50px] w-60 h-60 z-15"
              animate={{
                x: [0, -5, 0],
              }}
              transition={{
                duration: 6,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut",
                delay: 1.2,
              }}
            >
              <img
                src="/placeholder.svg?height=240&width=240"
                alt="Robotics Club"
                className="w-full h-full object-cover rounded-full shadow-neo border-4 border-black"
              />
            </motion.div>

            {/* Art Club - Center right, slightly above center */}
            <motion.div
              className="absolute top-[120px] right-[-80px] w-52 h-52 z-20"
              animate={{
                x: [0, 5, 0],
              }}
              transition={{
                duration: 6,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut",
                delay: 0.8,
              }}
            >
              <img
                src="/placeholder.svg?height=288&width=288"
                alt="Art Club"
                className="w-full h-full object-cover rounded-full shadow-neo-lg border-4 border-black"
              />
            </motion.div>

            {/* Environment Club - Bottom right */}
            <motion.div
              className="absolute bottom-[-72px] right-[60px] w-56 h-56 z-12"
              animate={{
                x: [0, -5, 0],
              }}
              transition={{
                duration: 6,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut",
                delay: 2.1,
              }}
            >
              <img
                src="/placeholder.svg?height=224&width=224"
                alt="Environment Club"
                className="w-full h-full object-cover rounded-full shadow-neo border-4 border-black"
              />
            </motion.div>

            {/* Drama Club - Bottom left */}
            <motion.div
              className="absolute bottom-[-98px] left-[40px] w-64 h-64 z-18"
              animate={{
                x: [0, 5, 0],
              }}
              transition={{
                duration: 6,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut",
                delay: 1.8,
              }}
            >
              <img
                src="/placeholder.svg?height=256&width=256"
                alt="Drama Club"
                className="w-full h-full object-cover rounded-full shadow-neo-lg border-4 border-black"
              />
            </motion.div>

            {/* Music Club - Center left, slightly below center */}
            <motion.div
              className="absolute left-[-96px] top-[220px] w-52 h-52 z-6"
              animate={{
                x: [0, -5, 0],
              }}
              transition={{
                duration: 6,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut",
                delay: 3.0,
              }}
            >
              <img
                src="/placeholder.svg?height=208&width=208"
                alt="Music Club"
                className="w-full h-full object-cover rounded-full shadow-neo border-4 border-black opacity-80"
              />
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  )
}
