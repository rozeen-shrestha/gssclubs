"use client"

import Link from "next/link"
import type React from "react"

interface TechBackgroundProps {
  children: React.ReactNode
  className?: string
  showGrid?: boolean
}

export default function TechBackground({
  children,
  className = "",
  showGrid = true,
}: TechBackgroundProps) {

  return (
    <div className={`relative overflow-hidden bg-background ${className}`}>
      {/* Infinite Grid Pattern Background */}
      {showGrid && (
        <div className="fixed inset-0">
          <div
            className="absolute inset-0 opacity-[0.03] dark:opacity-[0.05]"
            style={{
              backgroundImage: `
                linear-gradient(to right, currentColor 1px, transparent 1px),
                linear-gradient(to bottom, currentColor 1px, transparent 1px)
              `,
              backgroundSize: "80px 80px",
              color: "var(--foreground)",
            }}
          />
        </div>
      )}

      {/* Content */}
      <div className="relative z-10">{children}</div>
      {/* Watermark */}

      <div className="fixed bottom-2 right-2 z-50 select-none text-xs sm:text-sm font-ranade opacity-90">
        <Link
          href="https://instagram.com/gssitclub"
          target="_blank"
          rel="noopener noreferrer"
        >
          Designer/Developer: @gssitclub
        </Link>
      </div>
    </div>
  )
}
