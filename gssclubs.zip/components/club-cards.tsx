"use client"

import { motion } from "framer-motion"

interface Club {
  id: string
  name: string
  logo: string
  description: string
  color: string
}

const clubsData: Club[] = [
  {
    id: "1",
    name: "Science Club",
    logo: "/placeholder.svg?height=520&width=520",
    description: "Explore the wonders of science through experiments and discovery",
    color: "from-blue-500/20 to-cyan-500/20",
  },
  {
    id: "2",
    name: "Robotics Club",
    logo: "/placeholder.svg?height=520&width=520",
    description: "Build and program robots to solve real-world challenges",
    color: "from-purple-500/20 to-pink-500/20",
  },
  {
    id: "3",
    name: "Art Club",
    logo: "/placeholder.svg?height=520&width=520",
    description: "Express creativity through various forms of visual arts",
    color: "from-orange-500/20 to-red-500/20",
  },
  {
    id: "4",
    name: "Environment Club",
    logo: "/placeholder.svg?height=520&width=520",
    description: "Promote environmental awareness and sustainable practices",
    color: "from-green-500/20 to-emerald-500/20",
  },
  {
    id: "5",
    name: "Drama Club",
    logo: "/placeholder.svg?height=520&width=520",
    description: "Develop acting skills and perform captivating theatrical productions",
    color: "from-yellow-500/20 to-amber-500/20",
  },
  {
    id: "6",
    name: "Music Club",
    logo: "/placeholder.svg?height=520&width=520",
    description: "Create beautiful music and develop musical talents together",
    color: "from-indigo-500/20 to-blue-500/20",
  },
]

export default function ClubCards() {
  return (
    <section className="py-20 px-6 bg-blue-900/0">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="font-ranade font-black text-5xl md:text-6xl text-neo-yellow mb-4 uppercase tracking-tight">
            Our <span className="text-neo-teal">Clubs</span>
          </h2>
          <p className="font-ranade font-medium text-white text-lg max-w-2xl mx-auto">
            Discover your passion and join a community of like-minded students
          </p>
        </motion.div>

        {/* Club Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {clubsData.map((club, index) => (
            <motion.div
              key={club.id}
              className="group cursor-pointer"
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <div className="bg-blue-950/20 backdrop-blur-sm overflow-hidden border-4 border-black shadow-neo-lg hover:shadow-neo-xl hover:-translate-x-[2px] hover:-translate-y-[2px] transition-all duration-200 flex flex-col" style={{ minHeight: '420px' }}>
                <div className="relative h-64 overflow-hidden border-b-4 border-black">
                  <img
                    src={club.logo || "/placeholder.svg"}
                    alt={`${club.name} Logo`}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="flex-1 flex p-6 bg-blue-950/50 backdrop-blur-sm">
                  <div className="flex w-full gap-4 items-center">
                    <h3 className="font-ranade font-black text-2xl text-neo-yellow uppercase tracking-tight break-words text-left">
                      {club.name}
                    </h3>
                    <div className="bg-neo-teal text-white font-ranade font-bold text-sm px-4 py-2 uppercase tracking-wide border-4 border-black shadow-neo hover:shadow-neo-hover hover:translate-x-[2px] hover:translate-y-[2px] active:shadow-none active:translate-x-[4px] active:translate-y-[4px] transition-all duration-100 whitespace-nowrap">
                      Read more
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
