"use client"

import { useEffect, useState } from "react"
import { ChevronDown } from "lucide-react"

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10)
    window.addEventListener("scroll", onScroll)
    return () => window.removeEventListener("scroll", onScroll)
  }, [])

  return (
    <nav
      className={`sticky top-0 z-50 transition-all duration-300 ${scrolled ? "py-4" : "py-6"}`}
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className={`flex items-center justify-between transition-all duration-300 ${scrolled ? "bg-white border-4 border-black shadow-neo px-6 py-4" : "px-0 py-0"}`}>
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-neo-teal border-4 border-black shadow-neo flex items-center justify-center">
              <div className="w-6 h-6 bg-neo-yellow"></div>
            </div>
            <span className={`font-ranade font-black text-2xl md:text-3xl uppercase tracking-tight transition-colors ${scrolled ? "text-black" : "text-foreground"}`}>
              GSS CLUBS
            </span>
          </div>

          <div className="hidden md:flex items-center space-x-10">
            <a
              href="#"
              className={`font-ranade font-bold hover:text-neo-teal transition-colors uppercase tracking-wide ${scrolled ? "text-black" : "text-foreground"}`}
            >
              Home
            </a>
            <div className="flex items-center space-x-1">
              <a
                href="#"
                className={`font-ranade font-bold hover:text-neo-teal transition-colors uppercase tracking-wide ${scrolled ? "text-black" : "text-foreground"}`}
              >
                Clubs
              </a>
              <ChevronDown className={`w-4 h-4 ${scrolled ? "text-black" : "text-foreground"}`} />
            </div>
            <a
              href="#"
              className={`font-ranade font-bold hover:text-neo-teal transition-colors uppercase tracking-wide ${scrolled ? "text-black" : "text-foreground"}`}
            >
              Student Corner
            </a>
            <a
              href="#"
              className={`font-ranade font-bold hover:text-neo-teal transition-colors uppercase tracking-wide ${scrolled ? "text-black" : "text-foreground"}`}
            >
              Contact
            </a>
          </div>

          <div className="md:hidden">
            <div className={`w-6 h-6 ${scrolled ? "text-black" : "text-foreground"}`}>
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={3}>
                <path strokeLinecap="square" strokeLinejoin="miter" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </nav>
  )
}
