"use client"

import { motion } from "framer-motion"
import { Users, Calendar, MapPin } from "lucide-react"

export default function AffiliationCard() {
  return (
    <motion.div
      className="max-w-6xl mx-auto px-3 sm:px-8"
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: 0.6 }}
    >
      <div className="relative bg-blue-950/60 border-4 border-black p-6 sm:p-12 md:p-16 overflow-hidden shadow-neo-lg">
        {/* Background decoration */}
  <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 blur-3xl" />
  <div className="absolute bottom-0 left-0 w-48 h-48 bg-teal-500/10 blur-3xl" />

        <div className="relative z-10">
          <div className="flex flex-col md:flex-row items-center md:items-center gap-10 md:gap-16">
            {/* School Logo/Icon */}
            <div className="flex-shrink-0 flex justify-center items-center">
              <div className="w-40 h-24 sm:w-56 sm:h-32 bg-white flex items-center justify-center shadow-neo-lg border-4 border-black">
                <img
                  src="/global.jpg"

                  alt="Global School of Science Logo"
                  className="w-36 h-16 sm:w-48 sm:h-24 object-contain drop-shadow-lg"
                  draggable={false}
                />
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 text-center md:text-left flex flex-col justify-center">
              <h3 className="text-2xl md:text-3xl font-bold text-white mb-2 leading-tight">
                Proudly Affiliated with
                <br />
                <span className="text-neo-blue">
                  Global School of Science
                </span>
              </h3>
              <p className="text-slate-300 text-lg mb-6 leading-relaxed">
                We are the official Information Technology club of Global School of Science, fostering innovation
                and technical excellence among students since our establishment.
              </p>

              {/* Stats */}
              <div className="flex flex-col sm:flex-row gap-6 justify-center md:justify-start">
                <div className="flex items-center gap-3 justify-start">
                  <div className="w-10 h-10 bg-neo-blue flex items-center justify-center border-2 border-black">
                    <Users className="w-5 h-5 text-neo-yellow" />
                  </div>
                  <div className="text-left">
                    <div className="text-xl font-bold text-white">1700+</div>
                    <div className="text-sm text-slate-400">Active Students</div>
                  </div>
                </div>

                <div className="flex items-center gap-3 justify-start">
                  <div className="w-10 h-10 bg-neo-blue flex items-center justify-center border-2 border-black">
                    <Calendar className="w-5 h-5 text-neo-yellow" />
                  </div>
                  <div className="text-left">
                    <div className="text-xl font-bold text-white">50+</div>
                    <div className="text-sm text-slate-400">Events Organized</div>
                  </div>
                </div>

                <div className="flex items-center gap-3 justify-start">
                  <div className="w-10 h-10 bg-neo-blue flex items-center justify-center border-2 border-black">
                    <MapPin className="w-5 h-5 text-neo-yellow" />
                  </div>
                  <div className="text-left">
                    <div className="text-xl font-bold text-white">2019 AD</div>
                    <div className="text-sm text-slate-400">Established</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom accent */}
          <div className="mt-8 pt-6 border-t border-slate-700/50">
            <p className="text-center text-slate-400 text-sm">
              <MapPin className="w-4 h-4 inline mr-2" />
              Global School of Science, Kathmandu, Nepal
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
