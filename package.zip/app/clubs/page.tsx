import ClubCards from "@/components/club-cards"


export default function ClubsPage() {
  return (
    <main className="min-h-screen pt-14">
      <ClubCards />
    </main>
  )
}
