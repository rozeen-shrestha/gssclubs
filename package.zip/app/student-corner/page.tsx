import StudentCorner from "@/components/student-corner"

export default function StudentCornerPage() {
  return <StudentCorner />
}
