import Credits from "@/components/credits"

export default function CreditsPage() {
  return (
    <main className="min-h-screen">
      <Credits />
    </main>
  )
}
