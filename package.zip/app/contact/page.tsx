import Contacts from "@/components/contacts"

export default function ContactsPage() {
  return <Contacts />
}
